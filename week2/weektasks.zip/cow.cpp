#include<iostream>
using namespace std;

main(){
system("color 0F");
cout<< "                                                                                                                   \n";
cout<< "     ---------------------------------------------                                                                                                                  \n";
cout<< "                                                                                                                   \n";
cout<< "          o       ^___^                                                                                            \n";
cout<< "                                                                                                                   \n";
cout<< "               o  ( oo )\\__________________                                                                       \n";
cout<< "                                                                                                                   \n";
cout<< "                  (____)\\                   )\\/\\                                                                \n";
cout<< "                                                                                                                   \n";
cout<< "                        | |    ------w       |                                                                     \n";
cout<< "                                                                                                                   \n";
cout<< "                        | |                | |                                                                     \n";

}