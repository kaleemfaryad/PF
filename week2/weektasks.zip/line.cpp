#include<iostream>
using namespace std;

main(){
system("cls");
 system("color 46");
 cout <<" My first colorful text. ";


}